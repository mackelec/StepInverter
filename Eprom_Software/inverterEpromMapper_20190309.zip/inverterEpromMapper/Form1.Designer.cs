﻿namespace inverterEpromMapper
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgv_Transformers = new System.Windows.Forms.DataGridView();
            this.dgv_Map = new System.Windows.Forms.DataGridView();
            this.PrimaryVoltageM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndexM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhaseDegree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Voltage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VoltageActual = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tb_RecordLength = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_EpromSize = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_DCVoltage = new System.Windows.Forms.TextBox();
            this.tb_ACVoltage = new System.Windows.Forms.TextBox();
            this.button_calc = new System.Windows.Forms.Button();
            this.tb_numTransformers = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Index = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Factor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrimaryVoltage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SecondaryVoltage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrimaryTurns = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SecondaryTurns = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button_Generate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Transformers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Map)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_Transformers
            // 
            this.dgv_Transformers.AllowUserToAddRows = false;
            this.dgv_Transformers.AllowUserToDeleteRows = false;
            this.dgv_Transformers.AllowUserToOrderColumns = true;
            this.dgv_Transformers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Transformers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Index,
            this.txName,
            this.Factor,
            this.PrimaryVoltage,
            this.SecondaryVoltage,
            this.PrimaryTurns,
            this.SecondaryTurns,
            this.Note});
            this.dgv_Transformers.Location = new System.Drawing.Point(201, 38);
            this.dgv_Transformers.Name = "dgv_Transformers";
            this.dgv_Transformers.ReadOnly = true;
            this.dgv_Transformers.RowHeadersVisible = false;
            this.dgv_Transformers.Size = new System.Drawing.Size(611, 132);
            this.dgv_Transformers.TabIndex = 0;
            this.dgv_Transformers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Transformers_CellContentClick);
            // 
            // dgv_Map
            // 
            this.dgv_Map.AllowUserToAddRows = false;
            this.dgv_Map.AllowUserToDeleteRows = false;
            this.dgv_Map.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Map.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PrimaryVoltageM,
            this.IndexM,
            this.Phase,
            this.PhaseDegree,
            this.Voltage,
            this.VoltageActual});
            this.dgv_Map.Location = new System.Drawing.Point(201, 203);
            this.dgv_Map.Name = "dgv_Map";
            this.dgv_Map.ReadOnly = true;
            this.dgv_Map.Size = new System.Drawing.Size(611, 378);
            this.dgv_Map.TabIndex = 1;
            // 
            // PrimaryVoltageM
            // 
            this.PrimaryVoltageM.HeaderText = "Primary Voltage";
            this.PrimaryVoltageM.Name = "PrimaryVoltageM";
            this.PrimaryVoltageM.ReadOnly = true;
            this.PrimaryVoltageM.Width = 70;
            // 
            // IndexM
            // 
            this.IndexM.HeaderText = "Index";
            this.IndexM.Name = "IndexM";
            this.IndexM.ReadOnly = true;
            this.IndexM.Width = 40;
            // 
            // Phase
            // 
            this.Phase.HeaderText = "Phase";
            this.Phase.Name = "Phase";
            this.Phase.ReadOnly = true;
            this.Phase.Width = 40;
            // 
            // PhaseDegree
            // 
            this.PhaseDegree.HeaderText = "Degree";
            this.PhaseDegree.Name = "PhaseDegree";
            this.PhaseDegree.ReadOnly = true;
            this.PhaseDegree.Width = 60;
            // 
            // Voltage
            // 
            this.Voltage.HeaderText = "Voltage";
            this.Voltage.Name = "Voltage";
            this.Voltage.ReadOnly = true;
            this.Voltage.Width = 70;
            // 
            // VoltageActual
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.VoltageActual.DefaultCellStyle = dataGridViewCellStyle3;
            this.VoltageActual.HeaderText = "Voltage Actual";
            this.VoltageActual.Name = "VoltageActual";
            this.VoltageActual.ReadOnly = true;
            this.VoltageActual.Width = 70;
            // 
            // tb_RecordLength
            // 
            this.tb_RecordLength.Location = new System.Drawing.Point(130, 238);
            this.tb_RecordLength.Name = "tb_RecordLength";
            this.tb_RecordLength.Size = new System.Drawing.Size(46, 20);
            this.tb_RecordLength.TabIndex = 3;
            this.tb_RecordLength.Text = "1024";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 206);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Eprom Size";
            // 
            // cb_EpromSize
            // 
            this.cb_EpromSize.FormattingEnabled = true;
            this.cb_EpromSize.Items.AddRange(new object[] {
            "2716",
            "2732",
            "2764",
            "27128",
            "27256",
            "27512",
            "27C2001",
            "27C4001"});
            this.cb_EpromSize.Location = new System.Drawing.Point(104, 203);
            this.cb_EpromSize.Name = "cb_EpromSize";
            this.cb_EpromSize.Size = new System.Drawing.Size(72, 21);
            this.cb_EpromSize.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 241);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Record Length";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 277);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Nominal DC Voltage";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 310);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nominal AC Voltage";
            // 
            // tb_DCVoltage
            // 
            this.tb_DCVoltage.Location = new System.Drawing.Point(142, 277);
            this.tb_DCVoltage.Name = "tb_DCVoltage";
            this.tb_DCVoltage.Size = new System.Drawing.Size(34, 20);
            this.tb_DCVoltage.TabIndex = 9;
            this.tb_DCVoltage.Text = "26.5";
            // 
            // tb_ACVoltage
            // 
            this.tb_ACVoltage.Location = new System.Drawing.Point(142, 310);
            this.tb_ACVoltage.Name = "tb_ACVoltage";
            this.tb_ACVoltage.Size = new System.Drawing.Size(34, 20);
            this.tb_ACVoltage.TabIndex = 10;
            this.tb_ACVoltage.Text = "240";
            // 
            // button_calc
            // 
            this.button_calc.Location = new System.Drawing.Point(32, 582);
            this.button_calc.Name = "button_calc";
            this.button_calc.Size = new System.Drawing.Size(75, 23);
            this.button_calc.TabIndex = 11;
            this.button_calc.Text = "Calculate";
            this.button_calc.UseVisualStyleBackColor = true;
            this.button_calc.Click += new System.EventHandler(this.button_calc_Click);
            // 
            // tb_numTransformers
            // 
            this.tb_numTransformers.Location = new System.Drawing.Point(155, 40);
            this.tb_numTransformers.Name = "tb_numTransformers";
            this.tb_numTransformers.Size = new System.Drawing.Size(28, 20);
            this.tb_numTransformers.TabIndex = 12;
            this.tb_numTransformers.Text = "4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Number of Transformers";
            // 
            // Index
            // 
            this.Index.HeaderText = "Index";
            this.Index.Name = "Index";
            this.Index.ReadOnly = true;
            this.Index.Width = 50;
            // 
            // txName
            // 
            this.txName.HeaderText = "Name";
            this.txName.Name = "txName";
            this.txName.ReadOnly = true;
            // 
            // Factor
            // 
            this.Factor.HeaderText = "Factor";
            this.Factor.Name = "Factor";
            this.Factor.ReadOnly = true;
            this.Factor.Width = 50;
            // 
            // PrimaryVoltage
            // 
            this.PrimaryVoltage.HeaderText = "Primary Voltage";
            this.PrimaryVoltage.Name = "PrimaryVoltage";
            this.PrimaryVoltage.ReadOnly = true;
            this.PrimaryVoltage.Width = 60;
            // 
            // SecondaryVoltage
            // 
            this.SecondaryVoltage.HeaderText = "Secondary Voltage";
            this.SecondaryVoltage.Name = "SecondaryVoltage";
            this.SecondaryVoltage.ReadOnly = true;
            this.SecondaryVoltage.Width = 60;
            // 
            // PrimaryTurns
            // 
            this.PrimaryTurns.HeaderText = "Primary Turns";
            this.PrimaryTurns.Name = "PrimaryTurns";
            this.PrimaryTurns.ReadOnly = true;
            this.PrimaryTurns.Visible = false;
            this.PrimaryTurns.Width = 50;
            // 
            // SecondaryTurns
            // 
            this.SecondaryTurns.HeaderText = "Secondary Turns";
            this.SecondaryTurns.Name = "SecondaryTurns";
            this.SecondaryTurns.ReadOnly = true;
            this.SecondaryTurns.Visible = false;
            this.SecondaryTurns.Width = 70;
            // 
            // Note
            // 
            this.Note.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Note.HeaderText = "Note";
            this.Note.Name = "Note";
            this.Note.ReadOnly = true;
            // 
            // button_Generate
            // 
            this.button_Generate.Location = new System.Drawing.Point(32, 611);
            this.button_Generate.Name = "button_Generate";
            this.button_Generate.Size = new System.Drawing.Size(75, 23);
            this.button_Generate.TabIndex = 14;
            this.button_Generate.Text = "Generate";
            this.button_Generate.UseVisualStyleBackColor = true;
            this.button_Generate.Click += new System.EventHandler(this.button_Generate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 645);
            this.Controls.Add(this.button_Generate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_numTransformers);
            this.Controls.Add(this.button_calc);
            this.Controls.Add(this.tb_ACVoltage);
            this.Controls.Add(this.tb_DCVoltage);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cb_EpromSize);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_RecordLength);
            this.Controls.Add(this.dgv_Map);
            this.Controls.Add(this.dgv_Transformers);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.formInverterEpromMapper_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Transformers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Map)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Transformers;
        private System.Windows.Forms.DataGridView dgv_Map;
        private System.Windows.Forms.TextBox tb_RecordLength;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_EpromSize;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_DCVoltage;
        private System.Windows.Forms.TextBox tb_ACVoltage;
        private System.Windows.Forms.Button button_calc;
        private System.Windows.Forms.TextBox tb_numTransformers;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrimaryVoltageM;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndexM;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phase;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhaseDegree;
        private System.Windows.Forms.DataGridViewTextBoxColumn Voltage;
        private System.Windows.Forms.DataGridViewTextBoxColumn VoltageActual;
        private System.Windows.Forms.DataGridViewTextBoxColumn Index;
        private System.Windows.Forms.DataGridViewTextBoxColumn txName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Factor;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrimaryVoltage;
        private System.Windows.Forms.DataGridViewTextBoxColumn SecondaryVoltage;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrimaryTurns;
        private System.Windows.Forms.DataGridViewTextBoxColumn SecondaryTurns;
        private System.Windows.Forms.DataGridViewTextBoxColumn Note;
        private System.Windows.Forms.Button button_Generate;
    }
}

