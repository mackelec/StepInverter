﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace inverterEpromMapper
{
    class SinewaveMapper
    {
    }

    public class txMap
    {
        public double Vrms;
        public double Vdc;
        public int steps;
        public int TxNum;
        public int Eprom;
        public IList<txRow> rows = new List<txRow>();
        public TransformerList TxList = new TransformerList();
        public txLookup ctxLookup = new txLookup();

        public void run()
        {
            /*procRun();
            Vdc += 0.5;
            procRun();
            Vdc += 0.5;
            procRun();*/
            //procRun();
            int EpromSize = 1024;
            double voltStep = 0.10;
            switch (Eprom)
            {
                case 0: EpromSize = 2048;voltStep = 1; break;
                case 1: EpromSize = 4096; voltStep = 0.5; break;
                case 2: EpromSize = 8192; voltStep = 0.25; break;
                case 3: EpromSize = 0x4000; voltStep = 0.25; break;
                case 4: EpromSize = 0x8000; voltStep = 0.1; break;
                case 5: EpromSize = 0x10000; voltStep = 0.05; break;
                case 6: EpromSize = 0x40000; voltStep = 0.025; break;
                case 7: EpromSize = 0x80000; voltStep = 0.02; break;
            }
            int numMasks = EpromSize / steps;
            double saveVdc = Vdc;
            double saveVrms = Vrms;
            if (Eprom < 6)  // 6
            {
                Vdc = Vdc - voltStep * (numMasks / 2);
                for (int i = 0; i < numMasks - 1; i++)
                {
                    procRun();
                    Vdc += voltStep;
                }
            }
            else  // Hotwater programs also
            {
                Vdc = Vdc - voltStep * (numMasks / 4);
                for (int i = 0; i< (numMasks/2);i++)
                {
                    procRun();
                    Vdc += voltStep;
                }

                Vdc = saveVdc;
                double powerStep = (double) (90.0 / (numMasks / 2.0 - 1.0));
                double powerLevel = 100;

                for (int i = numMasks/2; i < numMasks-1; i++)
                {
                    Console.WriteLine("\n Power Level = {0}\n", powerLevel);
                    procRun();
                    powerLevel -= powerStep;
                    double pl = (double) powerLevel / 100.0;
                    Vrms = Math.Sqrt(pl) * saveVrms;
                }
            }
            // the last Mask (or Map) is reserved for clock board with no processor controlling it
            Vdc = saveVdc;
            Vrms = saveVrms;
            procRun();
            return;
            for (int i=0;i<31;i++)
            {
                double j = (double)i / 10.0;
                Vdc = 25 + j;
                procRun();
            }
            Vdc = 29;
            procRun();

        }

        private void procRun()
        {
            Console.WriteLine("Vdc = {0} \n", Vdc);
            ctxLookup.Vdc = Vdc;
            ctxLookup.txNum = TxNum;
            ctxLookup.TxList = TxList;
            ctxLookup.makeLookups();
            doSineCyle();
            double V = calcVrms();
            Console.WriteLine("\n simulated Vrms = {0}\n", V);
            writetoRomfile();
        }

        private void doSineCyle()
        {
            rows.Clear();
            Console.WriteLine("\n desired Vrms = {0}\n", Vrms);
            double Vpeak = Vrms * Math.Sqrt(2);
            int Vjunk = (int)(Vdc * 1000.0 + 0.5);
            int VrmsJunk = (int)(Vrms * 10.0 + 0.5);
            string filename = "EpromMapData_" + Vjunk.ToString() + "_" + VrmsJunk.ToString() + ".csv";
            if (!File.Exists(filename))
            {
                using (StreamWriter sw = File.CreateText(filename))
                {
                    sw.WriteLine("Offset,Degree,Vcalc,Vout,Tx Mask,Tx1,Tx2,Tx3,Tx4,Data");
                }
            
            }
            for (int i = 0; i < steps; i++)
            {
                double rad = 2 * Math.PI / steps * i;
                double degree = (360.0 * i) / steps;
                double volts = Math.Sin(rad) * Vpeak;
                txRow R = new txRow();
                AddNew_TxRow(ref R);
                R.voltage_ideal = volts;
                ctxLookup.set_TxRow(volts, ref R);
                using (StreamWriter sw = File.AppendText(filename))
                {
                    sw.WriteLine(i.ToString() + "," + degree.ToString() + "," + volts.ToString() + ","  + R.Voltage.ToString() + ",\"" + R.txMask.ToString() + "\"," +
                                R.txBits[0].Logic.ToString() + "," +
                                R.txBits[1].Logic.ToString() + "," +
                                R.txBits[2].Logic.ToString() + "," +
                                R.txBits[3].Logic.ToString() + ",\"" + R.dataMask + "\"");
                } 
                //Console.WriteLine("SineCycle index = {0}      degree = {1} Vcalc = {2} Vtx = {3} TMask = {4}  Txmask={5}  DataMask={6}", i, degree, volts, R.Voltage, R.ternaryMask,R.txMask,R.dataMask);
            }
        }
        
        public double calcVrms()
        {
            if (rows.Count < steps) return 0;
            double vrms = 0;
            double sqTotal = 0;
            foreach (txRow R in rows)
            {
                double Vtot = 0;
                if (R.txBits.Count == 0) continue;
                foreach (Txbit B in R.txBits)
                {
                    Vtot += B.Logic * Vdc * TxList.txList[B.txIndex].turnsRatio;
                }
                sqTotal += Vtot*Vtot;
            }
            sqTotal = sqTotal / rows.Count;
            vrms = Math.Sqrt(sqTotal);
            return vrms;
        }
        private void AddNew_TxRow(ref txRow Row)
        { 
            Row.txNum = TxNum;
            rows.Add(Row);
        }

        private void writetoRomfile()
        {
            if (rows.Count < steps) return ;
            byte[] buffer = new byte[rows.Count] ;
            
            int ptr = 0;
            for (int i=0;i< rows.Count;i++)
            {
                txRow R = rows[i];
                byte m = 0;
                for (int j = 0; j < R.txBits.Count; j++)
                {
                    Txbit B = R.txBits[j];
                    byte c = B.Crumb();
                    int mult = (int)Math.Pow(2, j);
                    switch (j)
                    {
                        case 3:mult = 1; break;
                        case 2:mult = 4; break;
                        case 1:mult = 16; break;
                        case 0:mult = 64; break;
                    }
                    c = Convert.ToByte( c * mult);
                     m += c;
                }
                buffer[ptr] = m;
                ptr++;
            }
            try
            {
                using (var fs = new FileStream("rom.bin", FileMode.Append, FileAccess.Write))
                {
                    fs.Write(buffer, 0, buffer.Length);
                    return ;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught in process: {0}", ex);
                return ;
            }
        }
    }

    public class txLookup
    {
        public double Vdc;
        public int txNum = 4;
        public IList<txRow> Lookups = new List<txRow>();
        public TransformerList TxList;
        public int size;
        public int index;
        public int lastindex;

        public void set_TxRow(double _volt, ref txRow _Row)
        {

            if (_volt >= 0)
            {
                for (int i = Lookups.Count-1; i > 0; i--)
                {
                    double Vth = (Lookups[i].Voltage + Lookups[i - 1].Voltage) / 2;
                    if (_volt >= Vth)
                    {
                        _Row.CopyLogicFrom(Lookups[i]);
                        return;
                    }
                }
            }
            else
            {
                for (int i = 0; i < Lookups.Count-1; i++)
                {
                    double Vth = (Lookups[i].Voltage + Lookups[i + 1].Voltage) / 2;
                    if (_volt <= Vth)
                    {
                        _Row.CopyLogicFrom(Lookups[i]);
                        return;
                    }
                }
            }
            

        }

        public void set_TxRow_old(double _volt, ref txRow _Row)
        {
            for (int i = 1; i < Lookups.Count; i++)
            {
                if (Lookups[i].Voltage == _volt)
                {
                    _Row.CopyLogicFrom(Lookups[i]);
                    return;
                }
                if (Lookups[i].Voltage > _volt && Lookups[i - 1].Voltage <= _volt)
                {
                    _Row.CopyLogicFrom(Lookups[i - 1]);
                    return;
                }
            }
            /*
                        foreach (txRow R in Lookups)
                        {
                            if (R.Voltage <= _volt)
                            {
                                _Row.CopyLogicFrom(R);
                                return;
                            }
                        }*/
        }

        public void makeLookups()
        {
            Lookups.Clear();
            size = (int) Math.Pow(3, txNum);
            for (int i=0;i< size;i++)
            {
                //http://stackoverflow.com/questions/923771/quickest-way-to-convert-a-base-10-number-to-any-base-in-net
                
                string txState = ternary.DecimalToArbitrarySystem(i, 3);
                int junk = Convert.ToInt32(txState);
                txState = junk.ToString("0000");
                //Console.Write("Index = {1} ternary count = {0}",txState,i);
                txRow R = new txRow();
                Lookups.Add (R);
                R.ternaryMask = txState;
                for (int j=0;j<txNum;j++)
                {
                    //continue;
                    Txbit B = new Txbit();
                    R.txBits.Add(B);
                    B.txIndex = j;
                    string s = txState.Substring(j, 1);
                    int v = Convert.ToInt32(s);
                    B.Logic = v -1;
                    B.volts = TxList.txList[j].returnVsec(Vdc);
                    B.volts = B.volts * B.Logic;
                    R.Voltage += B.volts;
                }
                //Console.WriteLine(" Voltage = {0}", R.Voltage);
            }
        }


    }

    public class txRow
    {
        public IList<Txbit> txBits = new List<Txbit>();
        public int txNum;
        public double Voltage;
        public int index;
        public double voltage_ideal;
        private string ternarymask = "" ;
        public string txMask = "";
        public string dataMask = "";

        public string ternaryMask
        {
            get { return ternarymask; }
            set
            {
                ternarymask = value;
                set_txMask();
            }
        }

        public void set_txMask()
        {
            string m;
            string r="";
            string c = "";
            for (int i =0; i< txNum;i++)
            {
                m = ternarymask.Substring(i, 1);
                switch (m)
                {
                    case "0": r += "-";c += "10"; break;
                    case "1": r += "0"; c += "00"; break;
                    case "2": r += "+"; c += "01"; break;
                }
            }
            txMask = r;
            dataMask = c;
        }
        public void set_txMask_old_20181209()
        {
            string m;
            string r = "";
            string c = "";
            for (int i = 0; i < txNum; i++)
            {
                m = ternarymask.Substring(i, 1);
                switch (m)
                {
                    case "0": r += "-"; c += "01"; break;
                    case "1": r += "0"; c += "11"; break;
                    case "2": r += "+"; c += "10"; break;
                }
            }
            txMask = r;
            dataMask = c;
        }

        public void CopyLogicFrom(txRow _Row)
        {
            ternaryMask = _Row.ternaryMask;
            for (int i=0;i< txNum;i++)
            {
                if (txBits.Count <= i)
                {
                    Txbit tB = new Txbit();
                    txBits.Add(tB);
                }
                txBits[i].Logic = _Row.txBits[i].Logic;
                txBits[i].txIndex = _Row.txBits[i].txIndex;
                txBits[i].volts = _Row.txBits[i].volts;
                Voltage = _Row.Voltage;

            }
        }
    }

    public class Txbit
    {
        public int txIndex;
        public double VoltsNominal;
        private int logic=0;
        
        public double volts;

        public int Logic
        {
            get
            {
                return logic;
            }
            set
            {
                logic = value;
            }
        }

        public byte Crumb()
        {
            switch (logic)
            {
                case -1:return 2; break; // 10
                case 0: return 0; break; // 11
                case 1: return 1; break; // 01
            }
            return 3;
        }
        public byte _old_201812_Crumb()
        {
            switch (logic)
            {
                case -1: return 1; break; // 01
                case 0: return 3; break; // 11
                case 1: return 2; break; // 01
            }
            return 3;
        }

    }

    public class TransformerList
    {
        public IList<txDetail> txList = new List<txDetail>();

        public void addTx(string _name,string _detail,double _Vprimary,double _Vsecondary)
        {
            txDetail D = new txDetail();
            D.Name = _name;
            D.Detail = _detail;
            D.Vprimary = _Vprimary;
            D.Vsecondary = _Vsecondary;
            txList.Add(D);
            D.index = txList.IndexOf(D);
        }
    }

    public class txDetail
    {
        public int index;
        public string Name = "";
        public string Detail = "";
        private double vprimary;
        private double vsecondary;
        private double turnsratio;

        public double Vprimary
        {
            get { return vprimary; }
            set
            {
                vprimary = value;
                if (vprimary != 0)
                {
                    turnsratio = vsecondary / vprimary;
                }
            }
        }
        
        public double Vsecondary
        {
            get { return vsecondary; }
            set
            {
                vsecondary = value;
                if (vprimary != 0)
                {
                    turnsratio = vsecondary / vprimary;
                }
            }
        }  
        
        public double returnVsec(double _Vprimary)
        {
            double vs = _Vprimary * turnsratio;
            return vs;
        }

        public double turnsRatio
        {
            get { return turnsratio; }
        }    
       
        

    }

    public class ternary
    {
        /// <summary>
        /// Converts the given decimal number to the numeral system with the
        /// specified radix (in the range [2, 36]).
        /// </summary>
        /// <param name="decimalNumber">The number to convert.</param>
        /// <param name="radix">The radix of the destination numeral system (in the range [2, 36]).</param>
        /// <returns></returns>
        public static string DecimalToArbitrarySystem(long decimalNumber, int radix)
        {
            const int BitsInLong = 64;
            const string Digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            if (radix < 2 || radix > Digits.Length)
                throw new ArgumentException("The radix must be >= 2 and <= " + Digits.Length.ToString());

            if (decimalNumber == 0)
                return "0";

            int index = BitsInLong - 1;
            long currentNumber = Math.Abs(decimalNumber);
            char[] charArray = new char[BitsInLong];

            while (currentNumber != 0)
            {
                int remainder = (int)(currentNumber % radix);
                charArray[index--] = Digits[remainder];
                currentNumber = currentNumber / radix;
            }

            string result = new String(charArray, index + 1, BitsInLong - index - 1);
            if (decimalNumber < 0)
            {
                result = "-" + result;
            }

            return result;
        }


        /// <summary>
        /// Converts the given number from the numeral system with the specified
        /// radix (in the range [2, 36]) to decimal numeral system.
        /// </summary>
        /// <param name="number">The arbitrary numeral system number to convert.</param>
        /// <param name="radix">The radix of the numeral system the given number
        /// is in (in the range [2, 36]).</param>
        /// <returns></returns>
        public static long ArbitraryToDecimalSystem(string number, int radix)
        {
            const string Digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            if (radix < 2 || radix > Digits.Length)
                throw new ArgumentException("The radix must be >= 2 and <= " +
                    Digits.Length.ToString());

            if (String.IsNullOrEmpty(number))
                return 0;

            // Make sure the arbitrary numeral system number is in upper case
            number = number.ToUpperInvariant();

            long result = 0;
            long multiplier = 1;
            for (int i = number.Length - 1; i >= 0; i--)
            {
                char c = number[i];
                if (i == 0 && c == '-')
                {
                    // This is the negative sign symbol
                    result = -result;
                    break;
                }

                int digit = Digits.IndexOf(c);
                if (digit == -1)
                    throw new ArgumentException(
                        "Invalid character in the arbitrary numeral system number",
                        "number");

                result += digit * multiplier;
                multiplier *= radix;
            }

            return result;
        }

    }


}
