﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inverterEpromMapper
{
    public partial class Form1 : Form
    {
        double Vpeak = 0;
        double Vdc = 0;
        double VACrms = 0;

        public txMap myMap = new txMap();

        public Form1()
        {
            InitializeComponent();
        }

        private void dgv_Transformers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void formInverterEpromMapper_Load(object sender, EventArgs e)
        {
            VACrms = Convert.ToDouble(tb_ACVoltage.Text);
            Vdc = Convert.ToDouble(tb_DCVoltage.Text);
            Vpeak = VACrms * Math.Sqrt(2);
            cb_EpromSize.SelectedIndex = 6;
            int numTx = Convert.ToInt32(tb_numTransformers.Text);
            proc_makeDGVTX(numTx);
            makeTXcolumns(numTx);
            fillTxList();
            //myMap.run();
        }

        public void proc_makeDGVTX(int num)
        {
            int B = makeBase(num);

            for (int i=0;i< num;i++)
            {
                int x = num - 1 - i;
                double F = Math.Pow(3, x)/B;
                double V = Vpeak * F ;

                dgv_Transformers.Rows.Add(i.ToString(),"",F.ToString(), tb_DCVoltage.Text,V.ToString());
            }
        }

        private void fillTxList()
        {
            myMap.steps = (int) Convert.ToInt32(tb_RecordLength.Text);
            myMap.TxNum = (int)Convert.ToInt32(tb_numTransformers.Text);
            myMap.Vrms = (double)Convert.ToDouble(tb_ACVoltage.Text);
            myMap.Vdc = (double)Convert.ToDouble(tb_DCVoltage.Text);
            TransformerList TL = myMap.TxList;
            TL.txList.Clear();
            foreach (DataGridViewRow R in dgv_Transformers.Rows)
            {
                string junk;
                junk = (string) R.Cells["PrimaryVoltage"].Value;
                double vp = Convert.ToDouble(junk);
                junk = (string)R.Cells["Secondaryvoltage"].Value;
                double vs = Convert.ToDouble(junk);
                TL.addTx("", "", vp, vs);
            }

            
        }

        public void makeTXcolumns(int txnum)
        {
            DataGridViewColumn C = dgv_Map.Columns["VoltageActual"];
            int index = C.Index;
            if (dgv_Map.Columns.Count > index+1)
            {
                for (int i = index + 1; i < dgv_Map.Columns.Count; i++)
                {
                    dgv_Map.Columns.RemoveAt(i);
                }
            }
            for (int i =0;i< txnum;i++)
            {
                string name = "TxLogic" + i.ToString();
                string title = "Tx" + i.ToString() + " Logic";
                dgv_Map.Columns.Add(name,title);
                dgv_Map.Columns[name].Width = 60;

                name = "TxVolts" + i.ToString();
                title = "Tx" + i.ToString() + " Volts";
                dgv_Map.Columns.Add(name, title);
                dgv_Map.Columns[name].Width = 60;
            }
            
        }

        public int makeBase(int num)
        {
            double cnt = 0;
            for (int i=0;i< num;i++)
            {
                cnt += Math.Pow(3, i);
            }
            return (int)cnt;
        }

        private void button_calc_Click(object sender, EventArgs e)
        {
            proc_Calc();
        }

        

        public void proc_Calc()
        {
            dgv_Map.Rows.Clear();
            VACrms = Convert.ToDouble(tb_ACVoltage.Text);
            Vdc = Convert.ToDouble(tb_DCVoltage.Text);
            Vpeak = VACrms * Math.Sqrt(2);
            int steps = Convert.ToInt32(tb_RecordLength.Text);
            makeMap(steps);
        }

        public void makeMap(int steps)
        {
            for (int i=0;i< steps;i++)
            {
                double rad = 2 * Math.PI / steps*i;
                double degree = (360.0 * i) /steps ;
                double volts = Math.Sin(rad) * Vpeak;
                dgv_Map.Rows.Add(Vdc.ToString(), i.ToString(), rad.ToString(),degree.ToString(), volts.ToString());
            }
        }

        private void button_Generate_Click(object sender, EventArgs e)
        {
            button_Generate.BackColor = Color.Red;
            Application.DoEvents();
            myMap.Eprom = cb_EpromSize.SelectedIndex;
            myMap.run();
            button_Generate.BackColor = Color.Green;
            Application.DoEvents();
            Console.Beep();
        }
    }
}
